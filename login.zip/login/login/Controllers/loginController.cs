﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using login.ViewModel;
using login.Models;

namespace login.Controllers
{
    public class loginController : Controller
    {
        //
        // GET: /login/
        public userContext db = new userContext();
        public ActionResult Index()
        {
            return View();

        }
        public ActionResult Create()
        {
            return View();

        }
        [HttpPost]
        public ActionResult Create(loginViewModel lm)
        {
            var u = db.userdemos.Where(x => x.username == lm.username & x.password == lm.password).FirstOrDefault();
            if(u==null)
            {
                ModelState.AddModelError("", "invalid username or pswrd");
                return View();
            }
            return RedirectToAction("Index","Home");
            return View();
        }

    }
}
