﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using login.Models;

namespace login.Controllers
{
    public class userdemoController : Controller
    {
        private userContext db = new userContext();

        //
        // GET: /userdemo/

        public ActionResult Index()
        {
            return View(db.userdemos.ToList());
        }

        //
        // GET: /userdemo/Details/5

        public ActionResult Details(int id = 0)
        {
            userdemo userdemo = db.userdemos.Find(id);
            if (userdemo == null)
            {
                return HttpNotFound();
            }
            return View(userdemo);
        }

        //
        // GET: /userdemo/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /userdemo/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(userdemo userdemo)
        {
            if (ModelState.IsValid)
            {
                db.userdemos.Add(userdemo);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(userdemo);
        }

        //
        // GET: /userdemo/Edit/5

        public ActionResult Edit(int id = 0)
        {
            userdemo userdemo = db.userdemos.Find(id);
            if (userdemo == null)
            {
                return HttpNotFound();
            }
            return View(userdemo);
        }

        //
        // POST: /userdemo/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(userdemo userdemo)
        {
            if (ModelState.IsValid)
            {
                db.Entry(userdemo).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(userdemo);
        }

        //
        // GET: /userdemo/Delete/5

        public ActionResult Delete(int id = 0)
        {
            userdemo userdemo = db.userdemos.Find(id);
            if (userdemo == null)
            {
                return HttpNotFound();
            }
            return View(userdemo);
        }

        //
        // POST: /userdemo/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            userdemo userdemo = db.userdemos.Find(id);
            db.userdemos.Remove(userdemo);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}