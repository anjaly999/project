﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace login.Models
{
    public class userContext:DbContext
    {
        public userContext()
            :base("con")
        {
            DropCreateDatabaseIfModelChanges<userContext> d=new DropCreateDatabaseIfModelChanges<userContext>();
            Database.SetInitializer<userContext>(d);


        }
        public DbSet<userdemo>userdemos{ get; set; }
    }
}