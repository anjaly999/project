﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace login.Models
{
    public class student
    {
        public int Id { get; set; }
        public int userdemoId { get; set; }

        public virtual userdemo userdemo { get; set; }
        
        [Required]
        [Display(Name = "Name")]
        public String uname { get; set; }
        [Required]
        [Display(Name = "Email")]
        public String email { get; set; }

        public Gender Genderlist{ get; set; }

    }
    public enum Gender
    {
        Male,
        Female
    }
}