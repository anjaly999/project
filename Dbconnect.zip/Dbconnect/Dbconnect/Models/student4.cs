﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Dbconnect.Models
{
    public class student4
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "NAME: ")]
        public String name { get; set; }
        [Required]
        [Display(Name = "EMAIL: ")]
        public String email { get; set; }
    }
}