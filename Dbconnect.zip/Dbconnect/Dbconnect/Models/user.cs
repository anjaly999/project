﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;


namespace Dbconnect.Models
{
    public class user
    {
        public int Id{ get; set; }
          
        [Required]
        [Display(Name="USERNAME: ")]
   
        public String uname { get; set; }
        [Required]
        [Display(Name = "PASSWORD: ")]
        [DataType(DataType.Password)]
        public String password { get; set; }
    }
}