﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MvcApplication1.Models
{
    public class emp
    {

        [Required]
        [Display(Name = "Employee Name")]
        [RegularExpression("a-zA-Z")]
        public String Sname { get; set; }
        [Required]
        [Display(Name = "Employee Email")]
        [DataType(DataType.EmailAddress)]
        public String Semail { get; set; }
        [Required]
        [Display(Name = "Employee Address")]
        [DataType(DataType.MultilineText)]
        public String Saddress { get; set; }
        [Required]
        [Display(Name = "Employee Salary")]
        [Range(1000, 10000)]
        public String Ssalary { get; set; }
    }
}