﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication1.Models;

namespace MvcApplication1.Controllers
{
    public class TestController : Controller
    {
        //
        // GET: /Test/

       
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult getString()
        {
            return View();
        }

        public ActionResult mystd()
        {
            student  s=new student();
            s.Sname="Ajce";
            s.Semail="ajce.ac.in";
            return View(s);
        }

        public ActionResult mycust()
        {
            return View();
        }

        public ActionResult myemp()
        {
            return View();
        }



    }
    
    
}
